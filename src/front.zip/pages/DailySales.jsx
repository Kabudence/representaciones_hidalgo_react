// src/components/DailySales.jsx
import { useState, useEffect } from "react";
import dailySalesService from "../services/dailySalesService";
import SaleDetailsModal from "../components/SaleDetailsModal.jsx";
import { FaSearch } from "react-icons/fa";

const DailySales = () => {
    // Estado para ventas diarias
    const [role, setRole] = useState(null);
    const [sales, setSales] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState("");
    const [historicalStatus, setHistoricalStatus] = useState("");
    const [isSearching, setIsSearching] = useState(false);
    // Estado para el modal de detalles de venta
    const [selectedIdCab, setSelectedIdCab] = useState(null);
    const [showModal, setShowModal] = useState(false);

    // Estado para el historial de ventas
    const [historicalSales, setHistoricalSales] = useState([]);
    const [historicalPage, setHistoricalPage] = useState(1);
    const [totalHistorical, setTotalHistorical] = useState(0);
    const [isHistoricalLoading, setIsHistoricalLoading] = useState(false);
    const [showHistorical, setShowHistorical] = useState(false);

    // Cargar las ventas diarias al montar el componente
    useEffect(() => {
        const storedUserData = sessionStorage.getItem("authData");
        if (storedUserData) {
            const { role } = JSON.parse(storedUserData);
            setRole(role);
        }
        fetchSales();
    }, []);

    const fetchSales = async () => {
        try {
            const data = await dailySalesService.getCompletedToday();
            setSales(data);
        } catch (error) {
            console.error("Error al obtener ventas diarias:", error);
        } finally {
            setIsLoading(false);
        }
    };

    const getStatusColor = (estado) => {
        switch ((estado || "").toUpperCase()) {
            case "ANULADO":
                return "#808080";
            case "COMPLETADO":
                return "blue";
            case "EN PROCESO":
                return "#d97706";
            default:
                return "#333";
        }
    };

    const canCompleteSale = (estado) => {
        return (estado || "").toUpperCase() === "EN PROCESO";
    };

    // Función para abrir el modal. Se valida que se reciba un id
    const openModal = (id) => {
        if (!id) {
            console.warn("No se ha recibido un id válido para el modal.");
            return;
        }
        setSelectedIdCab(id);
        setShowModal(true);
    };

    const closeModal = () => {
        setShowModal(false);
        setSelectedIdCab(null);
    };

    // 🔹 NUEVO: completar venta pidiendo el nombre del vendedor
    const handleCompleteSale = async (venta) => {
        if (!venta || !venta.idmov) {
            console.warn("No se recibió un idmov válido para completar la venta.");
            return;
        }

        const vendedor = window.prompt(
            "Ingrese el nombre (o DNI) de la persona que realizó la venta:"
        );

        // Si cancelan o dejan vacío, no hacemos nada
        if (!vendedor || !vendedor.trim()) {
            return;
        }

        try {
            await dailySalesService.changeStateToComplete(venta.idmov, vendedor.trim());
            // Refrescamos las ventas diarias
            await fetchSales();
            // Si está abierto el histórico, lo recargamos en la página actual
            if (showHistorical) {
                await loadHistoricalSales(historicalPage);
            }
        } catch (error) {
            console.error("Error al completar la venta:", error);
        }
    };

    // Función para cargar una página del historial con filtros opcionales
    const loadHistoricalSales = async (page = 1, customFilters = null) => {
        setIsHistoricalLoading(true);
        try {
            const activeFilters = customFilters || {
                numDocum: searchTerm.trim(),
                status: historicalStatus,
            };

            const result = await dailySalesService.getPage(page, 10, activeFilters);
            if (page === 1) {
                setHistoricalSales(result.ventas);
            } else {
                setHistoricalSales((prev) => [...prev, ...result.ventas]);
            }
            setTotalHistorical(result.total);
            setHistoricalPage(page);
        } catch (error) {
            console.error("Error al cargar ventas históricas:", error);
        } finally {
            setIsHistoricalLoading(false);
            setIsSearching(false);
        }
    };

    const handleSearch = async () => {
        const filters = {
            numDocum: searchTerm.trim(),
            status: historicalStatus,
        };

        if (!filters.numDocum && !filters.status) {
            clearSearch();
            return;
        }

        setIsSearching(true);
        await loadHistoricalSales(1, filters);
    };

    // Función para resetear la búsqueda y cargar la primera página del historial
    const clearSearch = () => {
        setSearchTerm("");
        setHistoricalStatus("");
        loadHistoricalSales(1, { numDocum: "", status: "" });
    };

    // Muestra u oculta la sección histórica
    const handleShowHistorical = () => {
        if (!showHistorical) {
            loadHistoricalSales(1);
        }
        setShowHistorical(!showHistorical);
    };

    // Cargar la siguiente página del historial
    const handleLoadMore = () => {
        const nextPage = historicalPage + 1;
        loadHistoricalSales(nextPage);
    };

    return (
        <div style={styles.container}>
            <h2 style={styles.title}>Ventas Diarias</h2>
            {isLoading ? (
                <p>Cargando ventas diarias...</p>
            ) : (
                <>
                    {sales.length === 0 ? (
                        <p>No hay ventas registradas hoy.</p>
                    ) : (
                        <div style={styles.cardList}>
                            {sales.map((venta, index) => (
                                <div key={index} style={styles.card}>
                                    <h3 style={styles.cardTitle}>
                                        {venta.num_docum || "Sin número de documento"}
                                    </h3>

                                    <p
                                        style={{
                                            ...styles.cardText,
                                            color: getStatusColor(venta.estado),
                                            fontWeight: "bold",
                                        }}
                                    >
                                        {venta.estado || "N/A"}
                                    </p>

                                    <p style={styles.cardText}>
                                        Cliente: {venta.cliente || "N/A"}
                                    </p>
                                    <p style={styles.cardText}>
                                        Estado: {venta.estado || "N/A"}
                                    </p>
                                    <p style={styles.cardText}>
                                        IGV: {venta.igv || "0.00"}
                                    </p>
                                    <p style={styles.cardText}>
                                        Valor de venta: {venta.vvta || "0.00"}
                                    </p>
                                    <p style={styles.cardText}>
                                        Total: {venta.total || "0.00"}
                                    </p>

                                    <button
                                        style={styles.button}
                                        onClick={() => {
                                            openModal(venta.idmov);
                                        }}
                                    >
                                        Más Información
                                    </button>

                                    {/* NUEVO: botón para completar venta */}
                                    {canCompleteSale(venta.estado) && (
                                        <button
                                            style={{ ...styles.button, marginLeft: "8px" }}
                                            onClick={() => handleCompleteSale(venta)}
                                        >
                                            Marcar como completada
                                        </button>
                                    )}
                                </div>
                            ))}
                        </div>
                    )}
                </>
            )}

            {/* Botón para mostrar u ocultar el registro histórico */}
            {role === "admin" && (
                <div style={{ marginTop: "20px", textAlign: "center" }}>
                    <button style={styles.button} onClick={handleShowHistorical}>
                        {showHistorical ? "Ocultar Registro Histórico" : "MOSTRAR REGISTRO HISTÓRICO"}
                    </button>
                </div>
            )}

            {/* Sección de historial */}
            {role === "admin" && showHistorical && (
                <div style={{ marginTop: "20px" }}>
                    <h2 style={styles.title}>Registro Histórico</h2>
                    <div style={styles.searchContainer}>
                        <div style={styles.searchFiltersRow}>
                            <div style={styles.statusFilterGroup}>
                                <label style={styles.filterLabel}>Buscar por Estado</label>
                                <select
                                    value={historicalStatus}
                                    onChange={(e) => setHistoricalStatus(e.target.value)}
                                    style={styles.statusSelect}
                                >
                                    <option value="">Todos</option>
                                    <option value="ANULADO">ANULADO</option>
                                    <option value="COMPLETADO">COMPLETADO</option>
                                    <option value="EN PROCESO">EN PROCESO</option>
                                </select>
                            </div>

                            <div style={styles.searchInputGroup}>
                                <input
                                    type="text"
                                    placeholder="Buscar por número de documento..."
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    style={styles.searchInput}
                                    onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                                />
                                <button
                                    style={styles.searchButton}
                                    onClick={handleSearch}
                                    disabled={isSearching}
                                >
                                    <FaSearch />
                                </button>
                                {(searchTerm || historicalStatus) && (
                                    <button
                                        style={styles.clearButton}
                                        onClick={clearSearch}
                                    >
                                        X
                                    </button>
                                )}
                            </div>
                        </div>
                    </div>

                    {isHistoricalLoading && historicalPage === 1 ? (
                        <p>Cargando registro histórico...</p>
                    ) : (
                        <>
                            {historicalSales.length === 0 ? (
                                <p>No hay registros históricos.</p>
                            ) : (
                                <div style={styles.cardList}>
                                    {historicalSales.map((venta, index) => (
                                        <div key={index} style={styles.card}>
                                            <h3 style={styles.cardTitle}>
                                                {venta.num_docum || "Sin número de documento"}
                                            </h3>

                                            <p
                                                style={{
                                                    ...styles.cardText,
                                                    color: getStatusColor(venta.estado),
                                                    fontWeight: "bold",
                                                }}
                                            >
                                                {venta.estado || "N/A"}
                                            </p>

                                            <p style={styles.cardText}>
                                                Cliente: {venta.cliente || "N/A"}
                                            </p>
                                            <p style={styles.cardText}>
                                                Estado: {venta.estado || "N/A"}
                                            </p>
                                            <p style={styles.cardText}>
                                                IGV: {venta.igv || "0.00"}
                                            </p>
                                            <p style={styles.cardText}>
                                                Valor de venta: {venta.vvta || "0.00"}
                                            </p>
                                            <p style={styles.cardText}>
                                                Total: {venta.total || "0.00"}
                                            </p>

                                            <button
                                                style={styles.button}
                                                onClick={() => {
                                                    openModal(venta.idmov || venta.idcab);
                                                }}
                                            >
                                                Más Información
                                            </button>

                                            {/* Opcional: también podrías permitir completar desde histórico */}
                                            {canCompleteSale(venta.estado) && (
                                                <button
                                                    style={{ ...styles.button, marginLeft: "8px" }}
                                                    onClick={() => handleCompleteSale(venta)}
                                                >
                                                    Marcar como completada
                                                </button>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            )}
                            {/* Botón para cargar más registros si aún hay más */}
                            {!searchTerm && !historicalStatus && historicalSales.length < totalHistorical && (
                                <div style={{ textAlign: "center", marginTop: "10px" }}>
                                    {isHistoricalLoading ? (
                                        <p>Cargando más...</p>
                                    ) : (
                                        <button style={styles.button} onClick={handleLoadMore}>
                                            Ver más...
                                        </button>
                                    )}
                                </div>
                            )}
                        </>
                    )}
                </div>
            )}

            {showModal && selectedIdCab && (
                <SaleDetailsModal idcab={selectedIdCab} onClose={closeModal} />
            )}
        </div>
    );
};

const styles = {
    container: {
        backgroundColor: "#f2f2f2",
        padding: "20px",
        margin: "10px auto",
        maxWidth: "90%",
        borderRadius: "8px",
    },
    title: {
        marginBottom: "15px",
        fontFamily: "'PT Sans Narrow', sans-serif",
        fontSize: "32px",
        textAlign: "center",
    },
    cardList: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
        gap: "16px",
    },
    card: {
        backgroundColor: "#fff",
        borderRadius: "8px",
        padding: "16px",
        boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
    },

    cardTitle: {
        fontSize: "18px",
        fontWeight: "bold",
        marginBottom: "8px",
    },
    cardText: {
        margin: "4px 0",
    },
    button: {
        marginTop: "8px",
        padding: "10px 20px",
        backgroundColor: "#524b4a",
        color: "white",
        border: "none",
        borderRadius: "5px",
        cursor: "pointer",
        fontWeight: "bold",
    },
    searchContainer: {
        marginBottom: "15px",
    },
    searchFiltersRow: {
        display: "flex",
        justifyContent: "center",
        alignItems: "flex-end",
        gap: "12px",
        flexWrap: "wrap",
    },
    statusFilterGroup: {
        display: "flex",
        flexDirection: "column",
        alignItems: "flex-start",
        gap: "6px",
    },
    filterLabel: {
        fontSize: "14px",
        fontWeight: "bold",
    },
    statusSelect: {
        padding: "8px",
        border: "1px solid #ccc",
        borderRadius: "5px",
        minWidth: "200px",
        outline: "none",
    },
    searchInputGroup: {
        display: "inline-flex",
        alignItems: "center",
    },
    searchInput: {
        padding: "8px",
        border: "1px solid #ccc",
        borderRadius: "5px 0 0 5px",
        outline: "none",
        width: "250px",
    },
    searchButton: {
        padding: "8px 12px",
        border: "none",
        backgroundColor: "#524b4a",
        color: "white",
        borderRadius: "0 5px 5px 0",
        cursor: "pointer",
    },
    clearButton: {
        marginLeft: "5px",
        padding: "8px 12px",
        border: "none",
        backgroundColor: "#dc3545",
        color: "white",
        borderRadius: "5px",
        cursor: "pointer",
    },
    buttonGroup: {
        marginTop: "12px",
        display: "flex",
        flexDirection: "column",
        gap: "8px",
    },

};

export default DailySales;
